package com.cardcounter.overlay

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.roundToInt

class OverlayService : Service() {

    companion object {
        const val ACTION_START = "com.cardcounter.overlay.START"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "card_counter_channel"
        private const val NOTIF_ID = 1

        // Only these tokens are ever accepted as a card rank. Anything else
        // OCR reads (game UI text, chip amounts, buttons...) is ignored.
        private val VALID_RANKS = setOf("A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K")
    }

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: View
    private lateinit var params: WindowManager.LayoutParams

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0

    private val counter = CardCounter()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            tearDownCapture()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START) {
            startForeground(NOTIF_ID, buildNotification())

            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)

            if (resultData != null) {
                setupCapture(resultCode, resultData)
                showOverlay()
            }
        }
        return START_NOT_STICKY
    }

    // ---------- Screen capture setup ----------

    private fun setupCapture(resultCode: Int, resultData: Intent) {
        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi

        val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
        mediaProjection?.registerCallback(projectionCallback, mainHandler)

        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "CardCounterCapture",
            screenWidth, screenHeight, screenDensity,
            android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, mainHandler
        )
    }

    private fun tearDownCapture() {
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.unregisterCallback(projectionCallback)
        mediaProjection?.stop()
        virtualDisplay = null
        imageReader = null
        mediaProjection = null
    }

    // ---------- Overlay UI ----------

    private fun showOverlay() {
        val inflater = LayoutInflater.from(this)
        overlayView = inflater.inflate(R.layout.overlay_layout, null)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 40
        params.y = 120

        windowManager.addView(overlayView, params)
        setupDrag()
        setupButtons()
        refreshCountUi()
    }

    private fun setupDrag() {
        val dragHandle = overlayView.findViewById<View>(R.id.dragHandle)
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f

        dragHandle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - touchX).roundToInt()
                    params.y = initialY + (event.rawY - touchY).roundToInt()
                    windowManager.updateViewLayout(overlayView, params)
                    true
                }
                else -> false
            }
        }
    }

    private fun setupButtons() {
        overlayView.findViewById<View>(R.id.btnClose).setOnClickListener {
            stopSelf()
        }
        overlayView.findViewById<View>(R.id.btnScan).setOnClickListener {
            performScan()
        }
        overlayView.findViewById<View>(R.id.btnNewRound).setOnClickListener {
            counter.newRound()
            setLastScanText("Nové kolo - pozice karet zapomenuty")
        }
        overlayView.findViewById<View>(R.id.btnReset).setOnClickListener {
            counter.resetShoe()
            refreshCountUi()
            setLastScanText("Count vynulován (nová bota)")
        }
        overlayView.findViewById<View>(R.id.btnDeckMinus).setOnClickListener {
            counter.adjustDecks(-0.5)
            refreshCountUi()
        }
        overlayView.findViewById<View>(R.id.btnDeckPlus).setOnClickListener {
            counter.adjustDecks(0.5)
            refreshCountUi()
        }
        overlayView.findViewById<View>(R.id.btnManualMinus).setOnClickListener {
            counter.manualAdjust(-1)
            refreshCountUi()
        }
        overlayView.findViewById<View>(R.id.btnManualPlus).setOnClickListener {
            counter.manualAdjust(1)
            refreshCountUi()
        }
    }

    private fun refreshCountUi() {
        overlayView.findViewById<TextView>(R.id.tvRunningCount).text = counter.runningCount.toString()
        overlayView.findViewById<TextView>(R.id.tvTrueCount).text =
            String.format("%.1f", counter.trueCount())
        overlayView.findViewById<TextView>(R.id.tvDecks).text =
            String.format("%.1f", counter.decksRemaining)
    }

    private fun setLastScanText(text: String) {
        overlayView.findViewById<TextView>(R.id.tvLastScan).text = text
    }

    // ---------- Capture + OCR ----------

    private fun performScan() {
        val reader = imageReader ?: return
        setLastScanText("Skenuji...")

        // Give the display a brief moment to render a fresh frame before we grab it.
        mainHandler.postDelayed({
            val image = reader.acquireLatestImage()
            if (image == null) {
                setLastScanText("Žádný nový snímek - zkus to znovu")
                return@postDelayed
            }
            val bitmap = imageToBitmap(image)
            image.close()

            if (bitmap == null) {
                setLastScanText("Snímek se nepodařilo zpracovat")
                return@postDelayed
            }

            val excludeRect = overlayScreenRect()
            val inputImage = InputImage.fromBitmap(bitmap, 0)

            recognizer.process(inputImage)
                .addOnSuccessListener { visionText ->
                    val detections = mutableListOf<CardCounter.Detection>()
                    for (block in visionText.textBlocks) {
                        for (line in block.lines) {
                            for (element in line.elements) {
                                val raw = element.text.trim().uppercase()
                                val rank = normalizeRank(raw) ?: continue
                                val box = element.boundingBox ?: continue
                                val cx = box.centerX().toFloat()
                                val cy = box.centerY().toFloat()

                                // Ignore anything detected inside our own overlay panel.
                                if (excludeRect != null &&
                                    cx > excludeRect[0] && cx < excludeRect[2] &&
                                    cy > excludeRect[1] && cy < excludeRect[3]
                                ) continue

                                detections.add(CardCounter.Detection(rank, cx, cy))
                            }
                        }
                    }

                    val newlyCounted = counter.processDetections(detections)
                    mainHandler.post {
                        refreshCountUi()
                        setLastScanText(
                            if (newlyCounted.isEmpty())
                                "Nalezeno ${detections.size} karet, 0 nových"
                            else
                                "Nové karty: ${newlyCounted.joinToString(", ")}"
                        )
                    }
                }
                .addOnFailureListener {
                    mainHandler.post { setLastScanText("OCR selhalo: ${it.message}") }
                }
        }, 150)
    }

    /** Rank text must be exactly one of the valid Blackjack ranks - filters out UI noise. */
    private fun normalizeRank(raw: String): String? {
        val cleaned = raw.replace(".", "").replace(",", "").trim()
        return if (VALID_RANKS.contains(cleaned)) cleaned else null
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width

            val bitmap = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)
            Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height)
        } catch (e: Exception) {
            null
        }
    }

    /** Screen-space rect [left, top, right, bottom] of our own overlay panel, so we can ignore its own text. */
    private fun overlayScreenRect(): FloatArray? {
        if (!::overlayView.isInitialized) return null
        val w = overlayView.width
        val h = overlayView.height
        if (w == 0 || h == 0) return null
        return floatArrayOf(
            params.x.toFloat(),
            params.y.toFloat(),
            (params.x + w).toFloat(),
            (params.y + h).toFloat()
        )
    }

    // ---------- Notification ----------

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Card Counter", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Blackjack Counter běží")
            .setContentText("Počítání karet aktivní")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::overlayView.isInitialized) {
            try { windowManager.removeView(overlayView) } catch (e: Exception) {}
        }
        tearDownCapture()
    }
}
