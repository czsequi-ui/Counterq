package com.cardcounter.overlay

import kotlin.math.hypot

/**
 * Hi-Lo card counting logic.
 *
 * Suit is intentionally ignored - Hi-Lo only cares about rank:
 *   2-6   -> +1
 *   7-9   ->  0
 *   10,J,Q,K,A -> -1
 *
 * Because we re-scan the same table screen repeatedly, we must avoid counting
 * the same physical card twice. We do this by remembering the screen position
 * of every rank we've already counted "this round" and only counting a newly
 * detected rank if there's no previously-counted detection close to it.
 */
class CardCounter {

    data class Detection(val rank: String, val x: Float, val y: Float)

    private data class Counted(val rank: String, val x: Float, val y: Float)

    var runningCount: Int = 0
        private set

    var decksRemaining: Double = 6.0
        private set

    private val countedThisRound = mutableListOf<Counted>()

    // How close (in pixels of the captured screenshot) two detections must be
    // to be considered "the same card". Tune this if you get double counts
    // or missed cards on your screen resolution.
    private val proximityThresholdPx = 70f

    fun hiLoValue(rank: String): Int = when (rank.uppercase()) {
        "2", "3", "4", "5", "6" -> 1
        "7", "8", "9" -> 0
        "10", "J", "Q", "K", "A" -> -1
        else -> 0
    }

    /**
     * Feed in all rank detections found in the latest screenshot.
     * Returns the list of ranks that were newly counted (for user feedback).
     */
    fun processDetections(detections: List<Detection>): List<String> {
        val newlyCounted = mutableListOf<String>()

        for (d in detections) {
            val alreadyCounted = countedThisRound.any { c ->
                c.rank == d.rank && hypot((c.x - d.x).toDouble(), (c.y - d.y).toDouble()) < proximityThresholdPx
            }
            if (!alreadyCounted) {
                runningCount += hiLoValue(d.rank)
                countedThisRound.add(Counted(d.rank, d.x, d.y))
                newlyCounted.add(d.rank)
            }
        }
        return newlyCounted
    }

    /** Call when the table clears for a new hand. Keeps the running count, forgets positions. */
    fun newRound() {
        countedThisRound.clear()
    }

    /** Call when the shoe is reshuffled. Wipes everything. */
    fun resetShoe(newDecks: Double = decksRemaining) {
        runningCount = 0
        decksRemaining = newDecks
        countedThisRound.clear()
    }

    fun adjustDecks(delta: Double) {
        decksRemaining = (decksRemaining + delta).coerceIn(0.5, 8.0)
    }

    fun manualAdjust(delta: Int) {
        runningCount += delta
    }

    fun trueCount(): Double {
        return if (decksRemaining > 0) runningCount / decksRemaining else runningCount.toDouble()
    }
}
