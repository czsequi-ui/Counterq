# Blackjack Counter (overlay)

Plovoucí overlay, který se zobrazí nad tvou vlastní tréninkovou blackjack aplikací,
přes screen capture rozpozná ranky karet (OCR) a počítá Hi-Lo running count / true count.

## Jak to funguje

1. **MainActivity** – požádá o dvě oprávnění:
   - "Zobrazit přes jiné aplikace" (overlay okno)
   - Sdílení obrazovky (MediaProjection) – systémový dialog, potvrdíš při každém spuštění
2. **OverlayService** – běžící na pozadí jako foreground service:
   - vykreslí plovoucí panel (lze přetáhnout za "⠿ Card Counter")
   - na tlačítko **SCAN** vyfotí aktuální obrazovku, ořízne svoji vlastní plochu (aby nečetl sám sebe) a pošle snímek do ML Kit OCR
   - z rozpoznaného textu vezme jen tokeny odpovídající rankům karet (A,2-9,10,J,Q,K) – barva (suit) se pro Hi-Lo nepočítá, takže ji ignorujeme
   - každý rank spojí s jeho pozicí na obrazovce a porovná s již spočítanými kartami z aktuálního kola, aby stejnou kartu nezapočítal dvakrát
3. **CardCounter** – čistá Hi-Lo logika (2-6 = +1, 7-9 = 0, 10/J/Q/K/A = -1) + true count = running / zbývající balíčky

## Ovládání panelu

- **SCAN** – ručně spustí rozpoznání aktuálně viditelných karet (stiskni pokaždé, když se objeví nová karta)
- **NOVÉ KOLO** – vymaže si zapamatované pozice karet (aby stůl mohl znovu naskenovat nové karty na stejném místě), running count zůstává
- **RESET** – vynuluje count (použij při zamíchání nové boty)
- **Balíčky zbývá +/-** – ruční odhad počtu zbývajících balíčků pro výpočet true count
- **Ruční oprava +1/-1** – pokud OCR kartu špatně přečte nebo nedetekuje, doplníš/opravíš ručně

## Sestavení

1. Otevři složku `BlackjackCounter` v Android Studiu (Open an existing project)
2. Nech Gradle sync doběhnout (stáhne ML Kit a další závislosti – potřebuje internet)
3. Build > Build Bundle(s) / APK(s) > Build APK(s)
4. Nainstaluj vygenerované APK na telefon (Settings > povolit instalaci z neznámých zdrojů, pokud instaluješ mimo Play Store)

Minimální Android verze: 8.0 (API 26).

## Známá omezení

- **Přesnost OCR** závisí na velikosti/kontrastu ranku ve tvé appce. Pokud appka kreslí karty malé nebo s neobvyklým fontem, zvyš `proximityThresholdPx` v `CardCounter.kt` nebo přibliž hru (zoom), aby byl rank čitelnější.
- **SCAN je manuální** (ne kontinuální) – jednodušší a spolehlivější než automatické sledování v reálném čase; stiskneš ho pokaždé, když se objeví nová karta.
- **"NOVÉ KOLO" nerozezná automaticky konec ruky** – musíš ho stisknout sám, jinak riskuješ, že se karta na stejném místě přepočítá.
- Pokud appka drží staré karty na obrazovce (historie, discard tray) na stejné pozici napříč koly, dedupe podle pozice může některé nové karty na stejném místě přeskočit – v tom případě použij ruční opravu (+1/-1).

## Poznámka

Tahle appka je stavěná jako **osobní tréninkový nástroj nad tvou vlastní blackjack appkou**.
Používání podobného softwaru (overlay/automatické počítání) v reálném kasinu nebo nad
skutečnou hazardní hrou je v mnoha jurisdikcích nezákonné – nepoužívej to k ničemu jinému
než k tréninku.
